const TelegramBot = require('node-telegram-bot-api');
const CONFIG = require('./config.js');
const { 
  getMenuKeyboard, getCurrencyKeyboard, getAdminKeyboard, getPaginationKeyboard, 
  getTicketAnswerKeyboard, getTicketAnswerToSupportKeyboard, getRealBanUserKeyboard, getChooseLangKeyboard,
  getCloseTicketKeyboard
 } = require("./keyboards.js");

const getPayment = require('./libs/payment.js');
const getMess = require('./messages.js');

const User = require('./libs/User.js');
const Files = require('./libs/Files.js');
const Log = require('./libs/Log.js');
const Status = require('./libs/status.js');
const Ticket = require('./libs/Ticket.js')

const crud = new User();
const filesManager = new Files();
const logger = new Log();
const statusTracker = new Status();
const ticketController = new Ticket();

const express = require('express');
const app = express();

const token = CONFIG.TOKEN;

const bot = new TelegramBot(token, {polling: true});

app.use(express.json());

try {
  app.get('/', () => {
    console.log('/');
  })
  
  app.post('/callback', async (req, res) => {
    const chatId = req.query.c;
    const type = req.query.t;
    const period = req.query.p
  
  
    if (req?.body?.status == 'paid') {
      let lang = (await crud.getDataById(chatId))?.lang;
      let text = getMess(lang, 'purchase');
  
      await crud.updateStatus(chatId, 'subscribed');
  
      bot.sendMessage(chatId, text, {parse_mode: 'Markdown'});
      res.status(200).send('OK');
    } else {
      res.status(400).send('No');
    }
  });
  
  const PORT = CONFIG.PORT;
  
  app.listen(PORT, () => {
    console.log(PORT);
  });
  
  
  bot.on('channel_post', async (post) => {
    const chatId = post.chat.id;
    await logger.add(post);
  });
  
  const flags = {
      'notif': {},
      'ban': {},
      'uPs': {},
      'DOWNLOAD': {},
      'update_status': {},
      'upload_files': {},
      'support': {},
      'tickets_answ': {},
      'support_tickets_answ': {},
      'lang': {},
      'tickets_resend': {}
    }
  
    let lastTicketId = 0;
    let lastSupportId = 0;
    let page = 1;
  
  bot.onText(/\/start/, async (msg) => {
      const chatId = msg.chat.id;
      const text = msg.text;
      const exist = await crud.userExist(chatId);

      bot.sendMessage(chatId, 'Welcome!\nChoose language', getChooseLangKeyboard());
      flags['lang'][chatId] = true;
  });
  
  
  bot.on('message', async (msg) => {
      const chatId = msg.chat.id;
      const text = msg.text;
      const username = msg.from.username;

      let lang = (await crud.getDataById(chatId))?.lang;
  
      if (flags['notif'][chatId]) {
          flags['notif'][chatId] = false;
          const usersId = await crud.getAllUsers(); 
    
          usersId.forEach(userId => {
            bot.sendMessage(userId, text);
          });
    
      } else if (flags['ban'][chatId]) {
          flags['ban'][chatId] = false;
          const ban = await crud.ban(text);
    
          if (!ban) {
            bot.sendMessage(chatId, 'user not found');
            return;
          }
          bot.sendMessage(chatId, 'user succefuly banned', await getMenuKeyboard(chatId));
  
      } else if (flags['upload_files'][chatId]) {
        const filesStrings = text?.split('\n');
        let filesPass = [];
  
        let {numOfFiles, NameOfFiles, sizeOfFiles, sourceOfFiles} = await statusTracker.get();
        await statusTracker.update(Number(numOfFiles)+1, NameOfFiles, sizeOfFiles, sourceOfFiles);
  
        for (const e of filesStrings) {
          let [files, pass, size] = e.split(' - ');
        
          filesPass.push({ 
            files: files.split(','), 
            pass: pass, 
            type: 'Antipublic Logs Cloud', 
            date: Date.now(), 
            size: size 
          });
        }
  
        filesManager.add(filesPass);
        bot.sendMessage(chatId, 'data successfully added');
  
      } else if (flags['DOWNLOAD'][chatId]) {
        flags['DOWNLOAD'][chatId] = false;
        let dataOfUser = await crud.getDataById(chatId);
        let fileNames = text.split('\n');
        let passes = '\n';
  
        let channelId = '';
  
        for (let i = 0; i < fileNames.length; i++) {
          let statusType = await filesManager.getTypeOfFile(fileNames[i]);
  
          if (statusType?.includes('Antipublic')) {
            channelId = CONFIG.ANTI_CHANNEL_ID;
          } else if (statusType?.includes('Hidden')) {
            channelId = CONFIG.HIDDEN_CHANNEL_ID;
          }
    
  
          let pass = await filesManager.getsPassOfFile(fileNames[i], dataOfUser.subscription);
          if (pass == undefined) pass = '-';
          passes += `${pass}\n`;
  
          let messIds = await logger.getIdWhereName(fileNames[i]);
  
          try {
            for (let i = 0; i < messIds.length; i++) {
              await bot.forwardMessage(chatId, channelId, messIds[i]);
              await bot.sendMessage(chatId, pass);
            }
          } catch (e) {
            console.log(messIds, e.message);
          }
        }
      } else if (flags['update_status'][chatId]) {
        flags['update_status'][chatId] = false;
        const [ numOfFiles, NameOfFiles, sizeOfFiles, sourceOfFiles] = text.split('\n');
        await statusTracker.update(Number(numOfFiles), NameOfFiles, sizeOfFiles, sourceOfFiles);
  
        bot.sendMessage(chatId, 'status updated!');
      } else if (flags['upload_files'][chatId]) {
        flags['upload_files'][chatId] = false;
  
        const filesStrings = text?.split('\n');
        let filesPass = [];
  
        filesStrings.forEach(e => {
          let [files, pass] = e.split(' - ');
          filesPass.push( {files: files.split(','), pass: pass, type: 'subscribed', date: Date.now()} );
        })
  
        filesManager.add(filesPass);
        bot.sendMessage(chatId, 'data successfully added');
      } else if (flags['support'][chatId]) {
        flags['support'][chatId] = false;
        for (let i = 0; CONFIG.ADMIN_CHAT_ID.length > i; i++) {
          bot.sendMessage(CONFIG.ADMIN_CHAT_ID[i], '*New ticket!*\nCheck it in the Admin panel', {parse_mode: 'MarkDown'});
        }
        await ticketController.add(username, chatId, text);
        bot.sendMessage(chatId, getMess(lang, 'reported'));
  
      } else if (flags['tickets_resend'][chatId]) {
        flags['tickets_resend'][chatId] = false;
        flags['tickets_answ'][chatId] = true;

        const ticket = await ticketController.getTicketById(lastTicketId);
        await ticketController.updateTicket(ticket.id, {mess: text });
        let d = new Date(ticket.date).toLocaleDateString();
        const msg = `#new\n*${d}*\n\`@${ticket.username}\`\n\n${text}`;
        for (let i = 0; i < CONFIG.ADMIN_CHAT_ID.length; i++) {
          bot.sendMessage(CONFIG.ADMIN_CHAT_ID[i], msg, getTicketAnswerKeyboard(ticket.id));
        }

      } else if (flags['tickets_answ'][chatId]) {
        flags['tickets_answ'][chatId] = false;

        const ticket = await ticketController.getTicketById(lastTicketId);

        let msg = `${getMess(lang, 'suportAnsw')}\n${text}\n`;
        bot.sendMessage(ticket.userId, msg, await getTicketAnswerToSupportKeyboard(ticket));

      } else if (flags['support_tickets_answ'][chatId]) {
        flags['support_tickets_answ'][chatId] = false;
        flags['tickets_answ'][chatId] = true;
        const ticket = await ticketController.getTicketById(lastTicketId);

        let d = new Date(ticket.date).toLocaleDateString();

        await ticketController.updateTicket(ticket.id, {mess: text });
        const msg = `#new\n*${d}*\n\`@${ticket.username}\`\n\n${text}`;

        for (let i = 0; i < CONFIG.ADMIN_CHAT_ID.length; i++) {
          bot.sendMessage(CONFIG.ADMIN_CHAT_ID[i], msg, getTicketAnswerKeyboard(ticket.id)); 
        }
      } else if (flags['lang'][chatId]) {
        let qtext = '';
        if (text == '🇷🇺 Русский') qtext = 'Русский';
        if (text == '🇺🇸 English') qtext = 'English';
        if (text == '🇨🇳 中文') qtext = '中文';

        if (!['Русский', 'English', '中文'].includes(qtext)) {
          bot.sendMessage(chatId, 'Please choose correct language', getChooseLangKeyboard());
          return;
        }
  
        flags['lang'][chatId] = false;
        const exist = await crud.userExist(chatId);
        lang = qtext;

        if (!exist) {
          const data = {
              "subscription": "missing",
              "ban": false,
              "profileText": "",
              "lang": `${qtext}`
          }
  
          await crud.addUser(chatId, data);
          bot.sendMessage(chatId, getMess(lang, 'welcome'), await getMenuKeyboard(chatId));
      } else {
        await crud.updateLang(chatId, qtext);
        bot.sendMessage(chatId, getMess(lang, 'resetLang'), await getMenuKeyboard(chatId));
      }
      }

      switch (text) {
          case `💵 ${getMess(lang, 'buyCloudK')}`:
              let msg = getMess(lang, 'chooseCur');
              bot.sendMessage(chatId, msg, {reply_markup: getCurrencyKeyboard('subscribed', 'llifetime', 100)});
              break;
          case `🙋 ${getMess(lang, 'supportK')}`:
              let check = await ticketController.checkUserTicket(chatId);

              if (!check.status) {
                bot.sendMessage(chatId, getMess(lang, 'alreadyTicket'), await getCloseTicketKeyboard(check.ticket));
                return;
              }

              flags['support'][chatId] = true;
              bot.sendMessage(chatId, getMess(lang, 'writeProblem'), await getMenuKeyboard(chatId));
              break;
          case `📁 ${getMess(lang, 'statusK')}`:
            let statusData = await statusTracker.get();
              let msq = `
${getMess(lang, 'numOfFiles')} \`${statusData['numOfFiles']}\`
${getMess(lang, 'nameOfFiles')} \`${statusData['NameOfFiles']}\`
${getMess(lang, 'size')} \`${statusData['sizeOfFiles']}\`
${getMess(lang, 'soursec')} \`${statusData['sourceOfFiles']}\``;
  
              bot.sendMessage(chatId, msq, await getMenuKeyboard(chatId));
              break;
          case `📑 ${getMess(lang, 'freeLeaksK')}`:
              bot.sendMessage(chatId, 'https://t.me/+--3KhuD9xSg0ZmZi', await getMenuKeyboard(chatId));
              break;
          case `👤 ${getMess(lang, 'profileK')}`:
            const data = await crud.getDataById(chatId);
            let text = `${getMess(lang, 'profile')}\nID: \`${chatId}\`\n`;

            for (let field in data) {
              if (field != 'profileText'  && field != 'ban') {
                let fieldTrans = getMess(lang, field);
                text += `${fieldTrans}: \`${data[field]}\`\n`;
              }
            }

            text += `${data.profileText}`;

            bot.sendMessage(chatId, text, await getMenuKeyboard(chatId));
            break;
          case `✉️ ${getMess(lang, 'channelK')}`:
              bot.sendMessage(chatId, 'https://t.me/draincollect', await getMenuKeyboard(chatId));
              break;
          case 'ADMIN':
              const adminStatus = await crud.checkAdmin(chatId);
              if (!adminStatus) {
                bot.sendMessage(chatId, 'No!');
                return;
              }
              bot.sendMessage(chatId, 'admin panel', await getAdminKeyboard(chatId));
              break;
          case `📥 ${getMess(lang, 'downloadK')}`:
                flags['DOWNLOAD'][chatId] = true;
                const {files, date, mess} = await filesManager.getPerPage(page, await crud.getStatus(chatId));
    
                bot.sendMessage(chatId, `${mess}`, await getPaginationKeyboard());
                break;
          default:
              //bot.sendMessage(chatId, 'no');
              break;
      }
  });
  
  
  bot.on('callback_query', async (callbackQuery) => {
      const message = callbackQuery.message;
      const data = callbackQuery.data;
      const chatId = message.chat.id;

      let lang = (await crud.getDataById(chatId))?.lang;
    
      if (data.includes('getPayment')) {
        const [, cur, type, period, amount, network] = data.split('_');
  
        const paymentData = await getPayment(amount, cur, chatId, 'subscribed', period, network);
        const { payer_amount, payer_currency, address, address_qr_code } = paymentData.result;
  
        const base64Image = address_qr_code;
        const base64Data = base64Image.replace(/^data:image\/png;base64,/, '');
        const imgBuffer = Buffer.from(base64Data, 'base64');
  
        let text = `
__${getMess(lang, 'payment')}__
        
${getMess(lang, 'address')} \`${address}\`
${getMess(lang, 'amount')} \`${payer_amount} ${payer_currency}\`
${getMess(lang, 'curren')} \`${payer_currency}\``;
  
        try {
          bot.sendPhoto(chatId, imgBuffer, { caption: text, parse_mode: 'MarkdownV2'});
        } catch (e) {
          
        }
      } else if (data == 'sendNotif') {
          flags['notif'][chatId] = true;
          bot.sendMessage(chatId, 'Enter text of notification', await getMenuKeyboard(chatId));
    
        } else if (data == 'banUser') {
          // this is not banUser | it's get user function
          const usersId = await crud.getAllUsers();
          let arrData = [];    
          arrData.push(['userId', 'status', 'ban']);        
    
          for (let i = 0; i < usersId.length; i++) {
            let dataOfUser = await crud.getDataById(usersId[i]);
            arrData.push([usersId[i], dataOfUser.subscription, dataOfUser.ban]);
          }
          
          let text = formatTable(arrData);
          bot.sendMessage(chatId, text, getRealBanUserKeyboard());
        } else if (data == 'realBanUser') {
          bot.sendMessage(chatId, 'Enter the userId of the person to ban', await getMenuKeyboard(chatId));
          flags['ban'][chatId] = true;

        }
         else if (data == 'pagin_back') {
          try {
            if (page-1 == 0) page = 2; 
            const {files, date, mess} = await filesManager.getPerPage(--page, await crud.getStatus(chatId));
    
            bot.editMessageText(`${mess}`, {
              chat_id: message.chat.id,
              message_id: message.message_id,
              parse_mode: 'Markdown',
              reply_markup: (await getPaginationKeyboard(files))['reply_markup']
            });
          } catch (e) {
            
          }
        } else if (data == 'pagin_next') {
          try {
            const {files, date, mess} = await filesManager.getPerPage(++page, await crud.getStatus(chatId));
            
            bot.editMessageText(`${mess}`, {
              chat_id: message.chat.id,
              message_id: message.message_id,
              parse_mode: 'Markdown',
              reply_markup: (await getPaginationKeyboard(files))['reply_markup']
            });
          } catch (e) {
            
          }
        } else if (data == 'update_status') {
          flags['update_status'][chatId] = true;
          let statusData = await statusTracker.get();
          let msq = `
Number of Files: \`${statusData['numOfFiles']}\`
Name Files: \`${statusData['NameOfFiles']}\`
Size: \`${statusData['sizeOfFiles']}\`
Sources: \`${statusData['sourceOfFiles']}\``;
  
          bot.sendMessage(chatId, msq, await getMenuKeyboard(chatId));
          bot.sendMessage(chatId, 'Send new data, each with a new line', await getMenuKeyboard(chatId));
  
        } else if (data == 'upload_files') {
          flags['upload_files'][chatId] = true;
          bot.sendMessage(chatId, 'Enter files:');
  
        } else if (data == 'tickets') {
          const { tickets, date, mess, keyboard } = await ticketController.getTicketsPerPage(page);
          let d = new Date(date).toLocaleDateString();
          bot.sendMessage(chatId, `${d}`, {reply_markup: keyboard});
  
        } else if (data == 'tickets_back') {
          if (page-1 == 0) page = 2; 
          const { tickets, date, mess, keyboard } = await ticketController.getTicketsPerPage(--page);
          let d = new Date(date).toLocaleDateString();
          bot.editMessageText(`${d}`, {
            chat_id: message.chat.id,
            message_id: message.message_id,
            parse_mode: 'Markdown',
            reply_markup: keyboard
          });
  
        } else if (data == 'tickets_next') {
          const { tickets, date, mess, keyboard } = await ticketController.getTicketsPerPage(++page);
          let d = new Date(date).toLocaleDateString();

          bot.editMessageText(`${d}`, {
            chat_id: message.chat.id,
            message_id: message.message_id,
            parse_mode: 'Markdown',
            reply_markup: keyboard
          });

        } else if (data.includes('getTicket')) {
          const [, ticketId] = data.split('_');
          lastSupportId = chatId;
          lastTicketId = ticketId;

          const ticket = await ticketController.getTicketById(ticketId);
          let d = new Date(ticket.date).toLocaleDateString();
          if (ticket == null) {
            bot.sendMessage(chatId, 'Incorrect ticket');
            return;
          } else {
            const msg = `#new\n*${d}*\n\`@${ticket.username}\`\n\n${ticket?.mess}`;
            bot.sendMessage(chatId, msg, getTicketAnswerKeyboard(ticketId));
          }
        } else if (data.includes('answerTicket')) {
          flags['tickets_answ'][chatId] = true;
          const [, ticketId] = data.split('_');
          lastTicketId = ticketId;

          bot.sendMessage(chatId, 'Enter answer:');
        } else if (data.includes('answerToSupportTicket')) {
          flags['support_tickets_answ'][chatId] = true;
          const [, ticketId] = data.split('_');
          lastTicketId = ticketId;

          bot.sendMessage(chatId, 'Enter answer:');

        } else if (data.includes('closeTicket')) {
          const [, ticketId] = data.split('_');

          flags['tickets_answ'][chatId] = false;
          flags['support_tickets_answ'][chatId] = false;
          lastTicketId = 0;
          lastSupportId = 0;

          lang = (await crud.getDataById(ticketId.chatId))?.lang;

          await ticketController.resolveTicket(ticketId);
          bot.sendMessage(chatId, 'Ticket closed!');
          bot.sendMessage(ticketId.chatId, getMess(lang, 'ticketClosed'));

        } else if (data.includes('resendTicket')) {
          flags['tickets_resend'][chatId] = true;
          const [, ticketId] = data.split('_');
          lastTicketId = ticketId;

          bot.sendMessage(chatId, getMess(lang, 'enterMess'));
        }

        console.log(data);
  
      bot.answerCallbackQuery(callbackQuery.id);
  });
  
  function formatTable(rows) {
    try {
      const colWidths = rows[0].map((_, colIndex) => {
        return Math.max(...rows.map(row => String(row[colIndex]).length));
      });
  
      const formattedRows = rows.map(row => {
        return row.map((cell, colIndex) => {
          return String(cell).padEnd(colWidths[colIndex], ' ');
        }).join(' | ');
      });
  
      const separator = colWidths.map(width => '-'.repeat(width)).join('-|-');
      return '```\n' + [formattedRows[0], separator, ...formattedRows.slice(1)].join('\n') + '\n```';
    } catch (e) {
      console.log(e.message);
      return 'none';
    }
  }
  
} catch (e) {
  console.log(e.message);
}