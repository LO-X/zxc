module.exports = {
    TOKEN: '7805236130:AAFBfLbQnWIDFFw0EsExD8llfzilnWWo6BI',
    ANTI_CHANNEL_ID: '-1002301839925',
    HIDDEN_CHANNEL_ID: '-1002301839925',
    UPDATES_LINK: 'https://t.me/logssupplier',
    APL_CHECKER_LINK: 'https://t.me/aplchecker',
    LOG_SCAMS_LINK: 'https://t.me/logscams',
    HELP_LINK: 'https://t.me/logleader',
    URL_CALLBACK: 'https://aplog.lol',
    PAYMENT_API_KEY: 'ij9XvTwKR0u37cm08LPjoevEnC4IOqDOnuSREt4Ezunmd7NpxRZ6wfOsihrGzvQsTbwowWFRfHNIafwAtOaPxpwkeUQsewBFxjmjvvGxVU7yUXZEfkvzzVNDFloAhPAr',
    MERCHANT_KEY: 'b0906e70-f148-4693-ab82-36c50a96ed9a',
    ADMIN_CHAT_ID: [5910891839, 7058607094],
    PORT: 8102
}