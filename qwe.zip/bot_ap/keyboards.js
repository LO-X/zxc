const CRUD = require('./libs/User.js');
const crud = new CRUD();
const getMess = require('./messages.js');


const getChooseLangKeyboard = () => {
    return {
        reply_markup: {
            keyboard: [
                ['🇷🇺 Русский', '🇺🇸 English'],
            ],
            resize_keyboard: true
        },
        parse_mode: 'Markdown'
    }
}

const getMenuKeyboard = async (chatId) => {
    const status = await crud.checkStatus(chatId);
    const lang = (await crud.getDataById(chatId)).lang;

    return {
        reply_markup: {
            keyboard: [
                [getMess(lang, 'profileK'), getMess(lang, 'buyAccK')],
                [getMess(lang, 'updatesK'), 'APL CHECKER'],
                ['LOG SCAMS', getMess(lang, 'helpK')],
                [getMess(lang, 'downloadK')].filter(() => status),
                [await crud.checkAdmin(chatId) ? 'ADMIN': '']
            ],
            resize_keyboard: true
        },
        parse_mode: 'Markdown'
    }
}

const getCloudKeyboard = () => {
    return {
        reply_markup: {
            inline_keyboard: [
                [
                  { text: 'Antipublic Cloud', callback_data: 'Antipublic' },
                  { text: 'Hidden Cloud', callback_data: 'Hidden' },
                ],
                [{ text: 'Ap + Hide Clouds', callback_data: 'AntiAndHidden' }]
            ]
        },
        parse_mode: 'Markdown'
    }
};

const getCloudPriceKeyboard = (cloud, lang) => {
    switch (cloud) {
        case 'Antipublic':
            return getAntipublicPriceKeyboard(lang);
        case 'Hidden':
            return getHiddenPriceKeyboard(lang);
        case 'AntiAndHidden':
            return getApAndHiidenPriceKeyboard(lang);
        default:
            return undefined;
    }
}

const getAntipublicPriceKeyboard = (lang) => {
    return {
        inline_keyboard: [
            [
              { text: `$400 / 1 ${getMess(lang, 'month')}`, callback_data: 'pay_Antipublic_1m_400' },
              { text: `$1500 / ${getMess(lang, 'lifetime')}`, callback_data: 'pay_Antipublic_Lifetime_1500' }
            ],
            [
              { text: getMess(lang, 'back'), callback_data: 'back' }
            ]
          ]
    }
}

const getHiddenPriceKeyboard = (lang) => {
    return {
        inline_keyboard: [
            [
              { text: `$500 / 1 ${getMess(lang, 'month')}`, callback_data: 'pay_Hidden_1m_500' },
              { text: `$2000 / ${getMess(lang, 'lifetime')}`, callback_data: 'pay_Hidden_Lifetime_2000' }
            ],
            [
                { text: getMess(lang, 'back'), callback_data: 'back' }
            ]
          ]
    }
}

const getApAndHiidenPriceKeyboard = (lang) => {
    return {
        inline_keyboard: [
            [
              { text: `$600 / 1 ${getMess(lang, 'month')}`, callback_data: 'pay_AntiAndHidden_1m_600' },
              { text: `$3000 / ${getMess(lang, 'lifetime')}`, callback_data: 'pay_AntiAndHidden_Lifetime_3000' }
            ],
            [
                { text: getMess(lang, 'back'), callback_data: 'back' }
            ]
          ]
    }
}

const getCurrencyKeyboard = (type, period, amount) => {
    return {
        inline_keyboard: [
            [
              { text: 'BTC', callback_data: `getPayment_BTC_${type}_${period}_${amount}_BTC` },
              { text: 'LTC', callback_data: `getPayment_LTC_${type}_${period}_${amount}_LTC` },
              { text: 'ETH', callback_data: `getPayment_ETH_${type}_${period}_${amount}_ETH` },
              { text: 'TRX', callback_data: `getPayment_TRX_${type}_${period}_${amount}_TRON` },
              { text: 'XMR', callback_data: `getPayment_XMR_${type}_${period}_${amount}_XMR` },
            ],
            [
                { text: 'USDT (ETH)', callback_data: `getPayment_USDT_${type}_${period}_${amount}_ETH` },
                { text: 'USDT (TRON)', callback_data: `getPayment_USDT_${type}_${period}_${amount}_TRON` },
            ]
        ],
    }
}

const getAdminKeyboard = async (chatId) => {
    return {
        reply_markup: {
            inline_keyboard: [
                [
                  { text: 'send notification', callback_data: 'sendNotif' },
                  { text: 'ban user', callback_data: 'banUser' },
                ],[
                    { text: 'set profile message', callback_data: 'uPs' },
                    { text: 'upload Files', callback_data: 'uFp' }
                ]
            ]
        },
        parse_mode: 'Markdown'
    }
}

const getChooseCloudKeyboard = async () => {
    return {
        reply_markup: {
            inline_keyboard: [
                [
                  { text: 'Antipublic Logs Cloud', callback_data: 'upload_ALC' },
                  { text: 'Hidden Cloud', callback_data: 'upload_HC' },
                ]
            ]
        },
        parse_mode: 'Markdown'
    }
}

const getPaginationKeyboard = async () => {
    return {
        reply_markup: {
            inline_keyboard: [
                [
                  { text: '<--', callback_data: 'pagin_back' },
                  { text: '-->', callback_data: 'pagin_next' },
                ]
            ]
        },
        parse_mode: 'Markdown'
    }
}

const getPreDownloadKeyboard = async () => {
    return {
        reply_markup: {
            inline_keyboard: [
                [
                  { text: 'Antipublic', callback_data: 'pre_Antipublic' },
                  { text: 'Hidden', callback_data: 'pre_Hidden' },
                ]
            ]
        },
        parse_mode: 'Markdown'
    }
}

module.exports = { 
    getMenuKeyboard, getCloudKeyboard,
    getAdminKeyboard, getChooseCloudKeyboard, 
    getCloudPriceKeyboard, getPaginationKeyboard,
    getCurrencyKeyboard, getPreDownloadKeyboard,
    getChooseLangKeyboard
}