module.exports = {
    TOKEN: '6435739801:AAHJZV9q0CDtJN8GAyXM_5RYuFp1MNb6g3k',
    ANTI_CHANNEL_ID: '-1002438196868',
    HIDDEN_CHANNEL_ID: '-1002200444339',
    UPDATES_LINK: 'https://t.me/logssupplier',
    APL_CHECKER_LINK: 'https://t.me/aplchecker',
    LOG_SCAMS_LINK: 'https://t.me/logscams',
    HELP_LINK: 'https://t.me/logleader',
    URL_CALLBACK: 'https://aplog.lol',
    PAYMENT_API_KEY: 'ij9XvTwKR0u37cm08LPjoevEnC4IOqDOnuSREt4Ezunmd7NpxRZ6wfOsihrGzvQsTbwowWFRfHNIafwAtOaPxpwkeUQsewBFxjmjvvGxVU7yUXZEfkvzzVNDFloAhPAr',
    MERCHANT_KEY: 'b0906e70-f148-4693-ab82-36c50a96ed9a',
    ADMIN_CHAT_ID: [5910891839, 6724555238],
    PORT: 8101
}