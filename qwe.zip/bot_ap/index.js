const TelegramBot = require('node-telegram-bot-api');
const CONFIG = require('./config.js');
const { 
  getMenuKeyboard, getCloudKeyboard, getAdminKeyboard,
  getChooseCloudKeyboard, getCloudPriceKeyboard, getPaginationKeyboard, getCurrencyKeyboard,
  getPreDownloadKeyboard, getChooseLangKeyboard
} = require("./keyboards.js");

const getPayment = require('./libs/payment.js');
const getMess = require('./messages.js');

const User = require('./libs/User.js');
const Files = require('./libs/Files.js');
const Log = require('./libs/Log.js');

const express = require('express');
const app = express();

const token = CONFIG.TOKEN;

const bot = new TelegramBot(token, {polling: true});

const crud = new User();
const filesManager = new Files();
const logger = new Log();

app.use(express.json());

app.get('/', (req, res) => {
  res.send('ok');
})

app.post('/callback', async (req, res) => {
  const chatId = req.query.c;
  let type = req.query.t;
  const period = req.query.p

  if (req?.body?.status == 'paid') {
    let text = '';
    let qtype = type;
    let lang = (await crud.getDataById(chatId))?.lang;
    if (type == 'AntiAndHidden') qtype = 'Antipublic and Hidden';

    if (period == '1m') {
      const today = new Date();
      const nextMonth = new Date(today.setMonth(today.getMonth() + 1));
      const formattedDate = `${String(nextMonth.getDate()).padStart(2, '0')}.${String(nextMonth.getMonth() + 1).padStart(2, '0')}.${nextMonth.getFullYear()}`;

      await crud.updateExpDate(chatId, formattedDate);
      text = `${getMess(lang, 'purchase')} *${qtype}* ${getMess(lang, 'purchaseMRight')}`;
    } else {
      await crud.updateExpDate(chatId, 'Lifetime');
      text = `${getMess(lang, 'purchase')} *${qtype}* ${getMess(lang, 'purchaseFRight')}`;
    }

    await crud.updateStatus(chatId, type);

    bot.sendMessage(chatId, text, {parse_mode: 'Markdown'});
    res.status(200).send('OK');
  } else {
    res.status(400).send('No');
  }
});

const PORT = CONFIG.PORT;

app.listen(PORT, () => {
  console.log(PORT);
});


bot.on('channel_post', async (post) => {
  await logger.add(post);
});

const flags = {
  'notif': {},
  'ban': {},
  'uPs': {},
  'upload_ALC': {},
  'upload_HC': {},
  'DOWNLOAD': {},
  'PRE_DOWNLOAD': {},
  'lang': {}
}

let page = 1;

try {
  bot.on('message', async (msg) => {
    const chatId = msg.chat.id;
    const text = msg.text;
    const username = msg.from.username
    const chatType = msg.chat.type;
    let lang = (await crud.getDataById(chatId))?.lang;

    flags['PRE_DOWNLOAD'][chatId] = await crud.getStatus(chatId); 

    page = 1;

    if (flags['notif'][chatId]) {
      flags['notif'][chatId] = false;
      const usersId = await crud.getAllUsers(); 

      usersId.forEach(userId => {
        bot.sendMessage(userId, text);
      });

    } else if (flags['ban'][chatId]) {
      flags['ban'][chatId] = false;
      const ban = await crud.ban(text);

      if (!ban) {
        bot.sendMessage(chatId, 'user not found');
        return;
      }
      bot.sendMessage(chatId, 'user succefuly banned');

    } else if (flags['uPs'][chatId]) {
      flags['uPs'][chatId] = false;

      await crud.setProfileText(text);
      bot.sendMessage(chatId, 'user field successfully setted');

    } else if (flags['upload_ALC'][chatId]) {
      flags['upload_ALC'][chatId] = false;
      const filesStrings = text?.split('\n');
      let filesPass = [];

      filesStrings.forEach(e => {
        let [files, pass] = e.split(' - ');
        filesPass.push( {files: files.split(','), pass: pass, type: 'Antipublic Logs Cloud', date: Date.now()} );
      })

      filesManager.add(filesPass);
      bot.sendMessage(chatId, 'data successfully added');

    } else if (flags['upload_HC'][chatId]) {
      flags['upload_HC'][chatId] = false;
      const filesStrings = text?.split('\n');
      let filesPass = [];

      filesStrings.forEach(e => {
        let [files, pass] = e.split(' - ');
        filesPass.push( {files: files.split(','), pass: pass, type: 'Hidden', date: Date.now()} );
      })
      filesManager.add(filesPass);
      bot.sendMessage(chatId, 'data successfully added');

    } else if (flags['DOWNLOAD'][chatId]) {
      flags['DOWNLOAD'][chatId] = false;
      let dataOfUser = await crud.getDataById(chatId);
      let fileNames = text.split('\n');
      let passes = '\n';

      let channelId = '';

      for (let i = 0; i < fileNames.length; i++) {
        let statusType = await filesManager.getTypeOfFile(fileNames[i]);

        if (statusType?.includes('Antipublic')) {
          channelId = CONFIG.ANTI_CHANNEL_ID;
        } else if (statusType?.includes('Hidden')) {
          channelId = CONFIG.HIDDEN_CHANNEL_ID;
        }
  
        let pass = await filesManager.getsPassOfFile(fileNames[i], dataOfUser.status);
        if (pass == undefined) pass = '-';
        passes += `${pass}\n`;

        let messIds = await logger.getIdWhereName(fileNames[i]);
        try {
          for (let i = 0; i < messIds.length; i++) {
            await bot.forwardMessage(chatId, channelId, messIds[i]);
            await bot.sendMessage(chatId, pass);
          }
        } catch (e) {
          console.log(messIds, e.message);
          // await bot.sendMessage(chatId, 'file not found');
        }
      }
    } else if (flags['lang'][chatId]) {
      let qtext = '';
      if (text == '🇷🇺 Русский') qtext = 'Русский';
      if (text == '🇺🇸 English') qtext = 'English';
      if (!['🇷🇺 Русский', '🇺🇸 English'].includes(text)) {
        bot.sendMessage(chatId, 'Please choose correct language', getChooseLangKeyboard());
        return;
      }

      flags['lang'][chatId] = false;
      const exist = await crud.userExist(chatId);
      lang = qtext;
      if (!exist) {
        const data = {
          "status": "None",
          "expirationDate": "None",
          "userName": `${username}`,
          "ban": false,
          "profileText": "",
          "lang": `${qtext}`
        }

        await crud.addUser(chatId, data);
        bot.sendMessage(chatId, getMess(lang, 'welcome'), await getMenuKeyboard(chatId));
      } else {
        await crud.updateLang(chatId, qtext);
        bot.sendMessage(chatId, getMess(lang, 'resetLang'), await getMenuKeyboard(chatId));
      }
    }

    switch (text) {
        case '/start':
            bot.sendMessage(chatId, 'Welcome!\nChoose language', getChooseLangKeyboard());
            flags['lang'][chatId] = true;
            break;
        case getMess(lang, 'profileK'):
            const data = await crud.getDataById(chatId);
            let text = `${getMess(lang, 'profile')}\nID: \`${chatId}\`\n`;

            for (let field in data) {
              if (field != 'profileText') {
                let fieldTrans = getMess(lang, field);
                text += `${fieldTrans}: \`${data[field]}\`\n`;
              }
            }

            text += `${data.profileText}`;

            bot.sendMessage(chatId, text, await getMenuKeyboard(chatId));
            break;
        case getMess(lang, 'buyAccK'):
            bot.sendMessage(chatId, getMess(lang, 'hereBuy'), getCloudKeyboard());
            break;
        case getMess(lang, 'updatesK'):
            bot.sendMessage(chatId, CONFIG.UPDATES_LINK, await getMenuKeyboard(chatId));
            break;
        case 'APL CHECKER':
            bot.sendMessage(chatId, CONFIG.APL_CHECKER_LINK, await getMenuKeyboard(chatId));
            break;
        case 'LOG SCAMS':
            bot.sendMessage(chatId, CONFIG.LOG_SCAMS_LINK, await getMenuKeyboard(chatId));
            break;
        case getMess(lang, 'helpK'):
            bot.sendMessage(chatId, CONFIG.HELP_LINK, await getMenuKeyboard(chatId));
            break;
        case getMess(lang, 'downloadK'):
            const status = await crud.getStatus(chatId);
            if (status == 'AntiAndHidden') {
              bot.sendMessage(chatId, getMess(lang, 'plsChCloud'), await getPreDownloadKeyboard());
              break;
            }

            flags['DOWNLOAD'][chatId] = true;
            const {files, date, mess} = await filesManager.getPerPage(page, status);

            bot.sendMessage(chatId, `${mess}`, await getPaginationKeyboard(files));
            break;
        case 'Antipublic Logs Cloud':
            bot.sendMessage(chatId, getMess(lang, 'info'), getCloudKeyboard()); 
        break;
        case 'Hidden Cloud':
            bot.sendMessage(chatId, getMess(lang, 'info'), getCloudKeyboard());
            break;
        case 'ADMIN':
            const adminStatus = await crud.checkAdmin(chatId); 
            if (!adminStatus) {
              bot.sendMessage(chatId, 'No!');
              return;
            }
            bot.sendMessage(chatId, 'admin panel', await getAdminKeyboard(chatId));
            break;
        default:
            //bot.sendMessage(chatId, 'no');
            break;
    }
});


bot.on('callback_query', async (callbackQuery) => {
    const message = callbackQuery.message;
    const data = callbackQuery.data;
    const chatId = message.chat.id;
    let lang = (await crud.getDataById(chatId))?.lang;
  
    if (data === 'Antipublic') {
      bot.editMessageText(getMess(lang, 'bigInfoAnti'), {
        chat_id: message.chat.id,
        message_id: message.message_id,
        parse_mode: 'Markdown',
        reply_markup: getCloudPriceKeyboard('Antipublic', lang)
      });

    } else if (data === 'Hidden') {
      bot.editMessageText(getMess(lang, 'bigInfoHidden'), {
        chat_id: message.chat.id,
        message_id: message.message_id,
        parse_mode: 'Markdown',
        reply_markup: getCloudPriceKeyboard('Hidden', lang)
      });

    } else if (data == 'AntiAndHidden') {
      bot.editMessageText(getMess(lang, 'bigInfoAntiAndHidden'), {
        chat_id: message.chat.id,
        message_id: message.message_id,
        parse_mode: 'Markdown',
        reply_markup: getCloudPriceKeyboard('AntiAndHidden', lang)
      });

    } else if (data == 'back') {
        bot.editMessageText(getMess(lang, 'hereCan'), {
            chat_id: message.chat.id,
            message_id: message.message_id,
            parse_mode: 'Markdown',
            reply_markup: (await getCloudKeyboard(chatId))['reply_markup']
          });

    } else if (data == 'sendNotif') {
      flags['notif'][chatId] = true;
      bot.sendMessage(chatId, 'Enter text of notification', await getMenuKeyboard(chatId));

    } else if (data == 'banUser') {
      const usersId = await crud.getAllUsers();
      let arrData = [];    
      arrData.push(['userId', 'username', 'status']);        

      for (let i = 0; i < usersId.length; i++) {
        let dataOfUser = await crud.getDataById(usersId[i]);
        arrData.push([usersId[i], dataOfUser.userName, dataOfUser.status]);
      }

      let text = formatTable(arrData);
      bot.sendMessage(chatId, text, await getMenuKeyboard(chatId));
      bot.sendMessage(chatId, 'Enter the userId of the person to ban', await getMenuKeyboard(chatId));
      flags['ban'][chatId] = true;

    } else if (data == 'uPs') {
      bot.sendMessage(chatId, 'Enter new profile message');
      flags['uPs'][chatId] = true;

    } else if (data == 'uFp') {
      bot.sendMessage(chatId, 'Choose cloud', await getChooseCloudKeyboard());

    } else if (data == 'upload_ALC') {
      flags['upload_ALC'][chatId] = true;
      bot.sendMessage(chatId, 'Enter files:');

    } else if (data == 'upload_HC') {
      flags['upload_HC'][chatId] = true;
      bot.sendMessage(chatId, 'Enter files:');

    } else if (data == 'pagin_back') {
      try {
        if (page-1 == 0) page = 2; 
        const {files, date, mess} = await filesManager.getPerPage(--page, flags['PRE_DOWNLOAD'])?.[chatId];

        bot.editMessageText(`${mess}`, {
          chat_id: message.chat.id,
          message_id: message.message_id,
          parse_mode: 'Markdown',
          reply_markup: (await getPaginationKeyboard(files))['reply_markup']
        });
      } catch (e) {
        
      }

    } else if (data == 'pagin_next') {
      try {
        const {files, date, mess} = await filesManager.getPerPage(++page, flags['PRE_DOWNLOAD'][chatId]);
        
        bot.editMessageText(`${mess}`, {
          chat_id: message.chat.id,
          message_id: message.message_id,
          parse_mode: 'Markdown',
          reply_markup: (await getPaginationKeyboard(files))['reply_markup']
        });
      } catch (e) {
        
      }
    } else if (data.includes('pay')) {
      const [, type, period, amount] = data.split('_');

      bot.editMessageText(getMess(lang, 'chCur'), {
        chat_id: message.chat.id,
        message_id: message.message_id, 
        parse_mode: 'Markdown',
        reply_markup: getCurrencyKeyboard(type, period, amount)
      });
    } else if (data.includes('getPayment')) {
      try {
        const [, cur, type, period, amount, network] = data.split('_');

        const paymentData = await getPayment(amount, cur, chatId, type, period, network);
        const { payer_amount, payer_currency, address, address_qr_code } = paymentData.result;
  
        const base64Image = address_qr_code;
        const base64Data = base64Image.replace(/^data:image\/png;base64,/, '');
        const imgBuffer = Buffer.from(base64Data, 'base64');

        let text = `
__${getMess(lang, 'payment')}__
        
${getMess(lang, 'address')} \`${address}\`
${getMess(lang, 'amount')} \`${payer_amount} ${payer_currency}\`
${getMess(lang, 'curren')} \`${payer_currency}\``;

              bot.sendPhoto(chatId, imgBuffer, { caption: text, parse_mode: 'MarkdownV2'});
      } catch (e) {
        console.log(e.message);
      }
    } else if (data == 'pre_Antipublic') {
      flags['DOWNLOAD'][chatId] = true;

      flags['PRE_DOWNLOAD'][chatId] = 'Antipublic';
      const {files, date, mess} = await filesManager.getPerPage(page, 'Antipublic');

      bot.sendMessage(chatId, `${mess}`, await getPaginationKeyboard(files));

    } else if (data == 'pre_Hidden') {
      flags['DOWNLOAD'][chatId] = true;
      flags['PRE_DOWNLOAD'][chatId] = 'Hidden';
      const {files, date, mess} = await filesManager.getPerPage(page, 'Hidden');

      bot.sendMessage(chatId, `${mess}`, await getPaginationKeyboard(files));

    }
  
    bot.answerCallbackQuery(callbackQuery.id);
  });


  function formatTable(rows) {
    const colWidths = rows[0].map((_, colIndex) => {
        return Math.max(...rows.map(row => row[colIndex].length));
    });

    const formattedRows = rows.map(row => {
        return row.map((cell, colIndex) => {
            return cell.padEnd(colWidths[colIndex], ' ');
        }).join(' | ');
    });

    const separator = colWidths.map(width => '-'.repeat(width)).join('-|-');
    
    return '```\n' + [formattedRows[0], separator, ...formattedRows.slice(1)].join('\n') + '\n```';
  }
} catch (e) {
  console.log(e.message);
}
