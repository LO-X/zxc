module.exports = (lang, mess) => {
    let text = {
        'Русский': {
            welcome: 'Добро пожаловать!',
            resetLang: 'Язык изменен!',
            purchase: 'Вы приобрели',
            purchaseMRight: 'подписку на месяц!',
            purchaseFRight: 'подписку навсегда!',
            hereBuy: 'Здесь вы можете купить доступ',
            plsChCloud: 'Пожалуйста, выберите облако',
            info: 'информация',
            bigInfoAnti: `Антипаблик Логи Облако:
    Полные логи с куки + URL:ЛОГИН:ПАРОЛЬ.
    Много источников: Шеллы, Бэкдоры, Инсталлы и Экшендж.
    Только уникальные логи и многое другое.
    Ежедневные обновления.
    Логи с 2015 по 2024 год (сегодня).
          
    
    Цены:`,
            bigInfoHidden: `Скрытые Логи Облако:
    Полные логи с куки + URL:ЛОГИН:ПАРОЛЬ.
    Много источников: G-ADS, FB-ADS, YT-ADS, X-ADS, Эксплойты и Спам.
    Только уникальные логи и многое другое.
    Ежедневные обновления.
    Логи с 2015 по 2024 год (сегодня).
          
    
    Цены:`,
            bigInfoAntiAndHidden: `Antipublic и Hidden хранилище логов:
    Полные логи с куки + URL:LOGIN:PASS.
          

    Цены:`,
            hereCan: 'Здесь вы можете купить доступ',
            chCur: 'Выберите валюту:',
            profile: 'ПРОФИЛЬ:',
            userName: 'имя пользователя',
            status: 'статус',
            expirationDate: 'дата окончания',
            ban: 'бан',
            lang: 'язык',
            month: 'Месяц',
            lifetime: 'Навсегда',
            payment: 'ОПЛАТА:',
            address: 'Адрес:',
            amount: 'Сумма:',
            curren: 'Валюта:',
            back: 'назад',
    
            // mainKeyboard
            profileK: 'ПРОФИЛЬ',
            buyAccK: 'КУПИТЬ ДОСТУП',
            updatesK: 'ОБНОВЛЕНИЯ',
            helpK: 'ПОМОЩЬ',
            downloadK: 'СКАЧАТЬ',
        },
    
        'English': {
            welcome: 'Welcome!',
            resetLang: 'Language is changed!',
            purchase: 'You have purchased the',
            purchaseMRight: 'monthly subscription!',
            purchaseFRight: 'subscription forever!',
            hereBuy: 'Here you can buy access',
            plsChCloud: 'Please choose cloud',
            info: 'info',
            bigInfoAnti: `Antipublic Logs Cloud:
    Full Logs with Cookies + URL:LOGIN:PASS.
    Many Sources: Shells,Backdoors,Installs & Exchange.
    Only unique logs + more.
    Daily Updates.
    Logs from 2015 to 2024 (Today).
          
    
    Prices:`,
            bigInfoHidden: `Hidden Logs Cloud:
    Full Logs with Cookies + URL:LOGIN:PASS.
    Many Sources: G-ADS,FB-ADS,YT-ADS,X-ADS,Exploits & Spam.
    Only unique logs + more.
    Daily Updates.
    Logs from 2015 to 2024 (Today).
          
    
    Prices:`,
            bigInfoAntiAndHidden: `Antipublic and Hidden Logs Cloud:
    Full Logs with Cookies + URL:LOGIN:PASS.
          

    Prices:`,
            hereCan: 'Here you can buy access',
            chCur: 'Choose currency:',
            profile: 'PROFILE:',
            userName: 'username',
            status: 'status',
            expirationDate: 'expiration date',
            ban: 'ban',
            lang: 'language',
            month: 'Month',
            lifetime: 'Lifetime',
            payment: 'PAYMENT:',
            address: 'Address:',
            amount: 'Amount:',
            curren: 'Currency:',
            back: 'back',
    
            // mainKeyboard
            profileK: 'PROFILE',
            buyAccK: 'BUY ACCESS',
            updatesK: 'UPDATES',
            helpK: 'HELP',
            downloadK: 'DOWNLOAD',
        },
    
        '中文': {
            welcome: '欢迎光临!',
            resetLang: '语言已更改!',
            purchase: '您已购买',
            purchaseMRight: '月度订阅！',
            purchaseFRight: '永久订阅！',
            hereBuy: '您可以在此购买访问权限',
            plsChCloud: '请选择云服务',
            info: '信息',
            bigInfoAnti: `Antipublic日志云:
    完整日志，包含Cookies + URL:登录:密码。
    多个来源: Shells、后门、安装包和交换。
    仅限唯一日志+更多内容。
    每日更新。
    从2015到2024年的日志（今天）。
        
        
    价格:`,
            bigInfoHidden: `隐藏日志云:
    完整日志，包含Cookies + URL:登录:密码。
    多个来源: G-ADS, FB-ADS, YT-ADS, X-ADS, 漏洞和垃圾邮件。
    仅限唯一日志+更多内容。
    每日更新。
    从2015到2024年的日志（今天）。
        
        
    价格:`,
    bigInfoAntiAndHidden: `反公开和隐藏日志存储：
    带 cookie + URL:LOGIN:PASS 的完整日志。
          

    价格:`,
            hereCan: '您可以在此购买访问权限',
            chCur: '选择货币:',
            profile: '个人资料:',
            userName: '用户名',
            status: '状态',
            expirationDate: '到期日期',
            ban: '封禁',
            lang: '语言',
            month: '月',
            lifetime: '永久',
            payment: '支付:',
            address: '地址:',
            amount: '金额:',
            curren: '货币:',
            back: '后',
    
            // mainKeyboard
            profileK: '个人资料',
            buyAccK: '购买访问权限',
            updatesK: '更新',
            helpK: '帮助',
            downloadK: '下载',
        },
    }
    
    

    return text?.[lang]?.[mess];
}