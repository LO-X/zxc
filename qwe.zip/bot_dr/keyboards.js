const CRUD = require('./libs/User.js');
const crud = new CRUD();

const getMess = require('./messages.js');

const getChooseLangKeyboard = () => {
    return {
        reply_markup: {
            keyboard: [
                ['🇷🇺 Русский', '🇺🇸 English', '🇨🇳 中文'],
            ],
            resize_keyboard: true
        },
        parse_mode: 'Markdown'
    }
}

const getMenuKeyboard = async (chatId) => {
    const status = await crud.checkStatus(chatId);
    const lang = (await crud.getDataById(chatId)).lang;
    
    return {
        reply_markup: {
            keyboard: [
                [`👤 ${getMess(lang, 'profileK')}`, `💵 ${getMess(lang, 'buyCloudK')}`, `📁 ${getMess(lang, 'statusK')}`],
                [`🙋 ${getMess(lang, 'supportK')}`, `📑 ${getMess(lang, 'freeLeaksK')}`, `✉️ ${getMess(lang, 'channelK')}`],
                [`📥 ${getMess(lang, 'downloadK')}`].filter(() => status),
                [await crud.checkAdmin(chatId) ? 'ADMIN': '']
            ],
            resize_keyboard: true
        },
        parse_mode: 'Markdown'
    }
}

const getCurrencyKeyboard = (type, period, amount) => {
    return {
        inline_keyboard: [
            [
              { text: 'BTC', callback_data: `getPayment_BTC_${type}_${period}_${amount}_BTC` },
            ],
            [
                { text: 'LTC', callback_data: `getPayment_LTC_${type}_${period}_${amount}_LTC` },
            ],
            [
                { text: 'ETH', callback_data: `getPayment_ETH_${type}_${period}_${amount}_ETH` },
            ],
            [
                { text: 'USDT (ETH)', callback_data: `getPayment_USDT_${type}_${period}_${amount}_ETH` },
            ],
            [
                { text: 'USDT (TRON)', callback_data: `getPayment_USDT_${type}_${period}_${amount}_TRON` },
            ],
            [
                { text: 'TRX', callback_data: `getPayment_TRX_${type}_${period}_${amount}_TRON` },
            ],
            [
                { text: 'XMR', callback_data: `getPayment_XMR_${type}_${period}_${amount}_XMR` },
            ]
        ],
    }
}

const getAdminKeyboard = async () => {
    return {
        reply_markup: {
            inline_keyboard: [
                [
                  { text: 'send notification', callback_data: 'sendNotif' },
                  { text: 'get users', callback_data: 'banUser' },
                ],[
                    { text: 'upload Files', callback_data: 'upload_files' },
                    { text: 'update status', callback_data: 'update_status' },
                ],
                [ { text: 'tickets', callback_data: 'tickets' } ]
            ]
        },
        parse_mode: 'Markdown'
    }
}

const getPaginationKeyboard = async () => {
    return {
        reply_markup: {
            inline_keyboard: [
                [
                  { text: '<--', callback_data: 'pagin_back' },
                  { text: '-->', callback_data: 'pagin_next' },
                ]
            ]
        },
        parse_mode: 'Markdown'
    }
}

const getTicketAnswerKeyboard = (ticketId) => {
    return {
        reply_markup: {
            inline_keyboard: [
                [
                    { text: 'answer', callback_data: `answerTicket_${ticketId}` },
                ],
                [
                    { text: 'close ticket', callback_data: `closeTicket_${ticketId}` },
                ]
            ]
        },
        parse_mode: 'Markdown'
    }
}

const getTicketAnswerToSupportKeyboard = async (ticket) => {
    const lang = (await crud.getDataById(ticket.userId))?.lang;
    let ticketId = ticket.id;

    return {
        reply_markup: {
            inline_keyboard: [
                [
                  { text: getMess(lang, 'answer'), callback_data: `answerToSupportTicket_${ticketId}` },
                ],
            ]
        },
        parse_mode: 'Markdown'
    }
}

const getCloseTicketKeyboard = async (ticket) => {
    const lang = (await crud.getDataById(ticket?.userId))?.lang;
    let ticketId = ticket?.id;

    return {
        reply_markup: {
            inline_keyboard: [
                [
                    { text: getMess(lang, 'resendTicket2'), callback_data: `resendTicket_${ticketId}` },
                ],
                [
                    { text: getMess(lang, 'closeTicket'), callback_data: `closeTicket_${ticketId}` },
                ]
            ]
        },
        parse_mode: 'Markdown'
    }
}

const getRealBanUserKeyboard = () => {
    return {
        reply_markup: {
            inline_keyboard: [
                [
                  { text: 'ban user', callback_data: `realBanUser` },
                ],
            ]
        },
        parse_mode: 'Markdown'
    }
}

module.exports = { 
    getMenuKeyboard, getCurrencyKeyboard, getAdminKeyboard, getPaginationKeyboard, getTicketAnswerKeyboard,
    getTicketAnswerToSupportKeyboard, getRealBanUserKeyboard, getChooseLangKeyboard, getCloseTicketKeyboard
}